CREATE VIEW FullPathEntities as
WITH RECURSIVE FullPathEntities AS(
        SELECT FileSystemEntityId AS BaseSystemEntityId, ParentFileSystemEntityId AS CurrentParentEntityId, Name AS CurrentPath FROM FileSystemEntity
        UNION
        SELECT
            P.BaseSystemEntityId,
            FS.ParentFileSystemEntityId AS CurrentParentEntityId,
            FS.Name || '\' || P.CurrentPath AS CurrentPath
        FROM FullPathEntities AS P
        INNER JOIN FileSystemEntity AS FS ON
        FS.FileSystemEntityId = P.CurrentParentEntityId
)
SELECT FS.*,P.CurrentPath As FullPath
FROM FullPathEntities AS P
INNER JOIN FileSystemEntity AS FS ON FS.FileSystemEntityId = P.BaseSystemEntityId
WHERE CurrentParentEntityId IS NULL;

